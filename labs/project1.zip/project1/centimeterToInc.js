let cent = prompt("Please enter the measure in Centimeter: ")
let inches = ( cent * 0.393701 ) 
alert(cent + " centimeters equal : "+ inches.toFixed(2) + " inches.")