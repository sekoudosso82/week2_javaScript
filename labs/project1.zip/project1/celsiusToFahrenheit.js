let cel = prompt("Please enter the degree in Celsius: ")
let far = ( cel * (9/5) ) + 32
alert(cel + " degree celsius is equal : "+ far.toFixed(2) + " degree fahrenheit")