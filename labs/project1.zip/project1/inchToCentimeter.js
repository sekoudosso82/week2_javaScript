let inches = prompt("Please enter the measure in Inches: ")
let cent = ( inches * 2.54 ) 
alert(inches + " inches equal : "+ cent.toFixed(2) + " Centimeters.")