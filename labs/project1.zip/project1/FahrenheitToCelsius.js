let far = prompt("Please enter the degree in Fahrenheit: ")
let cel = ( far - 32 ) * (5/9)
alert(far + " degree fahrenheit is equal :"+ cel.toFixed(2) + " degree celsius")