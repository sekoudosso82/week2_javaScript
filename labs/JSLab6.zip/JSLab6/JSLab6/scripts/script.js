//The following lines of code meant to create a constant 
//variable. To hold the number of inches in a foot. 
const  constInches = 12;
console.log("constant :", constInches)

let numInches;
numInches = 12;
console.log("regular var :", constInches)

//The next lines of code are meant to prompt the user
//to enter their name and then print it out to the console.

var name = prompt("Enter your name.");
console.log("Your name is: " , name);

//Finally, fix the following code so that it alerts 
//users that my favorite food is sushi.

let food = "sushi";
console.log("My favorite food is "+food);

// alert 
alert("My favorite food is: " + food);